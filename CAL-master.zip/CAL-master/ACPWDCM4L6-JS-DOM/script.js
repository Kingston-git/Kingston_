function myFunction() {
    var a = 4;
    document.getElementById("demo").innerHTML = a*a;
  } 